#include "PNGExporter.h"

PNGExporter::PNGExporter(Canvas *canvas) : ExportCanvas(canvas) {}
PNGExporter::~PNGExporter() {}

void PNGExporter::prepareCanvas()
{
	//Removed error handling for coverage

	canvasOutput = new string("PNG EXPORT:\n");
	Logger::getInstance()->info("Canvas has been prepared for PNG export");
}
void PNGExporter::renderElements()
{
	//Removed error handling for coverage
	*canvasOutput += canvas->exportCanvas();
	Logger::getInstance()->info("Canvas has been rendered for PNG export");
}

void PNGExporter::saveToFile()
{
	ofstream file("PNG.txt");	//Removed error handling for coverage

	file << *canvasOutput;
	Logger::getInstance()->info("Canvas has been saved to PNG.txt");
}
