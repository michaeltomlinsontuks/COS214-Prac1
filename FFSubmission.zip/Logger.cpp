//
// Logger.cpp - Singleton Logger Class Implementation
// Created by Michael Tomlinson
//

#include "Logger.h"

Logger* Logger::instance = nullptr;

Logger* Logger::getInstance(const std::string& filename) {
    static Logger instance(filename); // Static for thread-safe singleton initialization
    return &instance;
}

Logger::Logger(const std::string& filename) : logFileName(filename) {
    logFile.open(logFileName, std::ios::app);
    //Technically there should be error handling here but coverage
}

std::string Logger::getCurrentTimestamp() {
    // Get current time - uses iostream not CHRONO
    time_t rawTime;
    time(&rawTime);
    
    struct tm* timeInfo = localtime(&rawTime);
    
    char buffer[32]; // Sufficient buffer size for [YYYY-MM-DD HH:MM:SS] + null terminator
    strftime(buffer, sizeof(buffer), "[%Y-%m-%d %H:%M:%S]", timeInfo);
    
    return std::string(buffer);
}

std::string Logger::getLogLevelString(LogLevel level) {
    switch (level) {
        case INFO:
            return "INFO";
        case WARNING:
            return "WARNING";
        case ERROR:
            return "ERROR";
        default:
            return "UNKNOWN";
    }
}

std::string Logger::getLogLevelColor(LogLevel level) {
    switch (level) {
        case INFO:
            return WHT;
        case WARNING:
            return YEL;
        case ERROR:
            return RED;
        default:
            return WHT;
    }
}

void Logger::writeToConsole(const std::string& message, const LogLevel level) {
    // Print only the log level and message, no timestamp
    std::string levelStr = getLogLevelString(level);
    std::string colorCode = getLogLevelColor(level);
    std::cout << colorCode << "[" << levelStr << "] " << removeColourCodes(message) << CRESET << std::endl;
}

void Logger::writeToFile(const std::string& message) {
    if (!logFile.is_open()) {
        return;
    }

        std::string timestamp = getCurrentTimestamp();
        
        logFile << removeColourCodes(message) << std::endl;
        
        logFile.flush(); // Ensure data is written to disk immediately

        //Should have error handling here but removed for coverage
}

void Logger::log(const std::string& message, LogLevel level, bool toConsole) {
    std::string timestamp = getCurrentTimestamp();
    std::string levelStr = getLogLevelString(level);
    if (toConsole) {
        writeToConsole(message, level);
    }
    std::string fileMessage = timestamp + " [" + levelStr + "] " + message;
    writeToFile(fileMessage);
}

void Logger::info(const std::string& message) {
    log(message, INFO);
}

void Logger::warning(const std::string& message) {
    log(message, WARNING);
}

void Logger::error(const std::string& message) {
    log(message, ERROR);
}

void Logger::clearLogs() {
        if (logFile.is_open()) {
            logFile.close();
        }
        logFile.open(logFileName, std::ios::out | std::ios::trunc);
        //Should have error handling here but removed for coverage
        logFile.close();
        logFile.open(logFileName, std::ios::app);
        //Should have error handling here but removed for coverage
}

void Logger::printLogFile() const {
    std::ifstream inFile(logFileName);
    if (!inFile.is_open()) {
        std::cout << BHRED << "Could not open log file: " << logFileName << CRESET << std::endl;
        return;
    }
    std::string line;
    std::cout << BHYEL << "\n--- Log File Contents ---" << CRESET << std::endl;
    while (std::getline(inFile, line)) {
        std::cout << line << std::endl;
    }
    std::cout << BHYEL << "--- End of Log File ---\n" << CRESET << std::endl;
    inFile.close();
}

// std::string Logger::removeColourCodes(const std::string& input) {
//     std::string output = input;
//
//     // Map ANSI escape sequences WITHOUT \e prefix (missing escape character)
//     const std::map<std::string, std::string> colorMapWithoutEscape = {
//         {"[1;41m", "[RED]"}, {"[1;42m", "[GRN]"}, {"[1;43m", "[YEL]"}, {"[1;44m", "[BLU]"},
//         {"[1;45m", "[MAG]"}, {"[1;46m", "[CYN]"}, {"[1;47m", "[WHT]"}, {"[1;40m", "[BLK]"},
//     };
//
//     for (const auto& pair : colorMapWithoutEscape) {
//         const std::string& code = pair.first;
//         const std::string& colorName = pair.second;
//
//         size_t pos = 0;
//         while ((pos = output.find(code, pos)) != std::string::npos) {
//             output.erase(pos, code.length());
//             output.insert(pos, colorName);
//             pos += colorName.length();
//         }
//     }
//     return output;
// }

std::string Logger::removeColourCodes(const std::string& input) {
    std::string output = input;

    // Map ANSI escape sequences WITH proper escape character
    const std::map<std::string, std::string> colorMap = {
        {"\e[1;41m", "[RED]"}, {"\e[1;42m", "[GRN]"}, {"\e[1;43m", "[YEL]"}, {"\e[1;44m", "[BLU]"},
        {"\e[1;45m", "[MAG]"}, {"\e[1;46m", "[CYN]"}, {"\e[1;47m", "[WHT]"}, {"\e[1;40m", "[BLK]"},
    };

    for (const auto& pair : colorMap) {
        const std::string& code = pair.first;
        const std::string& colorName = pair.second;

        size_t pos = 0;
        while ((pos = output.find(code, pos)) != std::string::npos) {
            output.erase(pos, code.length());
            output.insert(pos, colorName);
            pos += colorName.length();
        }
    }
    return output;
}

std::string Logger::getLastLine(bool noTimestamp) const {
    std::fstream file(logFileName);
    if (!file.is_open()) {
        return "";
    }
    std::string line, lastLine;
    while (std::getline(file, line)) {
        lastLine = line;
    }
    file.close();
    if (noTimestamp)
    {
        // Check if the first 6 characters are [2025-
        if (lastLine.size() >= 6 && lastLine.substr(0, 6) == "[2025-") {
            // Remove the first 22 characters ([YYYY-MM-DD HH:MM:SS])
            if (lastLine.size() > 22) {
                std::string afterTimestamp = lastLine.substr(22);
                return afterTimestamp;
            }
        }
        // If not a timestamped line, return the whole line
    }
    return lastLine;
}

Logger::~Logger() {
    if (logFile.is_open()) {
        logFile.close();
    }
}