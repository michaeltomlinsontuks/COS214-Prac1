#include "PDFExporter.h"

PDFExporter::PDFExporter(Canvas *canvas) : ExportCanvas(canvas) {}
PDFExporter::~PDFExporter() {}

void PDFExporter::prepareCanvas()
{
	//Removed error handling for coverage
	canvasOutput = new string("PDF EXPORT:\n");
	Logger::getInstance()->info("Canvas has been prepared for PDF export");
}
void PDFExporter::renderElements()
{
	//Removed error handling for coverage
	*canvasOutput += canvas->exportCanvas();
	Logger::getInstance()->info("Canvas has been locally rendered for PDF export");
}

void PDFExporter::saveToFile()
{
	ofstream file("PDF.txt"); 	//Removed error handling for coverage

	file << *canvasOutput;
	Logger::getInstance()->info("Canvas has been saved to PDF.txt");
}
